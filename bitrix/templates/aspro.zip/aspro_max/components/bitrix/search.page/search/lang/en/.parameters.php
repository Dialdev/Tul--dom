<?
$MESS["TP_BSP_USE_SUGGEST"] = "Показывать подсказку с поисковыми фразами";
$MESS["TP_BSP_SHOW_RATING"] = "Включить рейтинг";
$MESS["TP_BSP_SHOW_RATING_CONFIG"] = "по умолчанию";
$MESS["TP_BSP_RATING_TYPE"] = "Вид кнопок рейтинга";
$MESS["TP_BSP_RATING_TYPE_CONFIG"] = "по умолчанию";
$MESS["TP_BSP_RATING_TYPE_STANDART_TEXT"] = "Нравится / Не нравится (текстовый)";
$MESS["TP_BSP_RATING_TYPE_STANDART_GRAPHIC"] = "Нравится / Не нравится (графический)";
$MESS["TP_BSP_RATING_TYPE_LIKE_TEXT"] = "Мне нравится (текстовый)";
$MESS["TP_BSP_RATING_TYPE_LIKE_GRAPHIC"] = "Мне нравится (графический)";
$MESS["TP_BSP_PATH_TO_USER_PROFILE"] = "Шаблон пути к профилю пользователя";
?>