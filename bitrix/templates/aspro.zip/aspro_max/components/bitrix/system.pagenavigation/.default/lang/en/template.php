<?
$MESS ['nav_of'] = "of";
$MESS ['nav_begin'] = "First";
$MESS ['nav_prev'] = "Prev.";
$MESS ['nav_next'] = "Next";
$MESS ['nav_end'] = "Last";
$MESS ['nav_paged'] = "Paged";
$MESS ['nav_all'] = "All";
$MESS ['nav_to'] = "-";
?>