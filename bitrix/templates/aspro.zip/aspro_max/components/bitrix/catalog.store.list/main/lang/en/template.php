<?
$MESS["PHONE"] = "Телефон";
$MESS["SCHEDULE"] = "Режим работы";
$MESS["ADDRESS"] = "Адрес";
$MESS["METRO"] = "Станция метро";
$MESS["DETAIL"] = "Подробности";
?>
