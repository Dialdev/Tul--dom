$(document).on('click', ".scroll_btn", function(){
	scroll_block($('#right_block_ajax'));
});