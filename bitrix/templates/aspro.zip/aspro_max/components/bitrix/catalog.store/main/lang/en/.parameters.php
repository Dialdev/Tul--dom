<?
$MESS["GOOGLE_API_KEY"] = "API ключ google карт";
?>