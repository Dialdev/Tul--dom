<?
	$MESS["S_PHONE"] = "Телефон:";
	$MESS["S_SCHEDULE"] = "Режим работы:";
	$MESS["S_EMAIL"] = "E-mail:";
	$MESS["MEASURE_DEFAULT"] = "шт.";
	$MESS["BY_ORDER"] = "на заказ";
	$MESS["SUFFICIENT_GOODS"] = "достаточно";
	$MESS["NO_GOODS"] = "отсутствует";
	$MESS["FEW_GOODS"] = "мало";
	$MESS["MANY_GOODS"] = "много";
	$MESS["BALANCES"] = "Общее количество на складах";
	$MESS["NO_STORES"] = "Нет складов";

	$MESS["STORES_LIST"] = "Списком";
	$MESS["STORES_MAP"] = "На карте";
	$MESS["NO_STORES_COORDINATES"] = "Укажить координаты для складов";
?>
