<?
	$MESS["S_PHONE"] = "тел:";
	$MESS["S_SCHEDULE"] = "график работы:";
	$MESS["MEASURE_DEFAULT"] = "шт.";
	$MESS["S_EMAIL"] = "email:";
	$MESS["BY_ORDER"] = "на заказ";
	$MESS["SUFFICIENT_GOODS"] = "достаточно";
	$MESS["NO_GOODS"] = "отсутствует";
	$MESS["FEW_GOODS"] = "мало";
	$MESS["MANY_GOODS"] = "много";
	$MESS["BALANCES"] = "Общее количество на складах";
	$MESS["NO_STORES"] = "Нет складов";
	$MESS["MORE_LINK"] = "Подробности";
	$MESS["STORES_TITLE_ITEM"] = "Наличие";
?>
