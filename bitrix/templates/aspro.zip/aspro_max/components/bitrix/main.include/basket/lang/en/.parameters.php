<?
$MESS["PRICE_CODE_TITLE"] = 'Тип цены';
$MESS["STORES"] = "Склады";

$MESS["CP_BC_TPL_USE_BIG_DATA"] = "Показывать персональные рекомендации";
$MESS["CP_BC_TPL_BIG_DATA_RCM_TYPE"] = "Тип рекомендации";
$MESS["CP_BC_TPL_RCM_BESTSELLERS"] = "Самые продаваемые";
$MESS["CP_BC_TPL_RCM_PERSONAL"] = "Персональные рекомендации";
$MESS["CP_BC_TPL_RCM_SOLD_WITH"] = "Продаваемые с этим товаром";
$MESS["CP_BC_TPL_RCM_VIEWED_WITH"] = "Просматриваемые с этим товаром";
$MESS["CP_BC_TPL_RCM_SIMILAR"] = "Похожие товары";
$MESS["CP_BC_TPL_RCM_SIMILAR_ANY"] = "Продаваемые/Просматриваемые/Похожие товары";
$MESS["CP_BC_TPL_RCM_PERSONAL_WBEST"] = "Самые продаваемые/Персональные";
$MESS["CP_BC_TPL_RCM_RAND"] = "Любая рекомендация";

$MESS["SALE_STIKER"] = "Свойство со стикером акций";
$MESS["STIKERS_PROP_TITLE"] = "Свойство со стикерами";
$MESS["SHOW_DISCOUNT_PERCENT_NUMBER_NAME"] = "Отображать процент экономии";
?>