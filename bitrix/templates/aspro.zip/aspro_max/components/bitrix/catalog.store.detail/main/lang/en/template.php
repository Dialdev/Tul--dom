<?
$MESS["BACK_STORE_LIST"] = "Вернуться к списку магазинов";
$MESS["PHONE"] = "Телефон";
$MESS["SCHEDULE"] = "Режим работы";
$MESS["ADDRESS"] = "Адрес";
$MESS["METRO"] = "Станция метро";
?>

