<?
$MESS['RETRIEVE'] = 'Восстановить';
$MESS['REQUIRED_FIELDS'] = 'Обязательные поля';
$MESS['CAPTCHA_PROMT'] = 'Введите код';
$MESS['forgot_pass_login'] = 'Логин';
$MESS['forgot_pass_login_note'] = 'Контрольная строка для смены пароля, а также ваши регистрационные данные, будут высланы вам по E-Mail.';
$MESS['forgot_pass_phone_number'] = 'Номер телефона';
$MESS['forgot_pass_phone_number_note'] = 'Код для смены пароля будет выслан по СМС.';
$MESS['forgot_pass_phone_number_or_login'] = 'Логин или номер телефона';
$MESS['forgot_pass_sms_send'] = 'Получить код';
$MESS['AUTH_LOGIN'] = 'Логин или email:';
?>