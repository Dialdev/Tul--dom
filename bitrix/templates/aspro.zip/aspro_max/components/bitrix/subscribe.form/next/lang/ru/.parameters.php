<?
$MESS["URL_SUBSCRIBE_TITLE"]="Страница с подпиской";
?>