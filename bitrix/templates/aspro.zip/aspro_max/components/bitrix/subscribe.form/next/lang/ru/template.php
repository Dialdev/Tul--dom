<?
$MESS ['subscr_form_email_title'] = "Оставьте свой e-mail";
$MESS ['subscr_form_button'] = "Подписаться";
$MESS ['subscr_form_button_change'] = "Изменить";
$MESS ['TEXT_BLOCK_FOOTER'] = "Текст подписки";
?>