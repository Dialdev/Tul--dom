<?
$MESS ['subscr_form_email_title'] = "Ваш e-mail";
$MESS ['subscr_form_button'] = "Подписаться";
$MESS ['subscr_form_button_change'] = "Изменить";
$MESS ['TOP_BLOCK'] = "Верхний текст";
$MESS ['TEXT_BLOCK'] = "Нижний текст";
?>