<?
$MESS ['CATALOG_COMPARE_ELEMENTS'] = "Список сравниваемых товаров";
$MESS ['CATALOG_COMPARE_ELEMENTS_TITLE'] = "Сравнение";
?>