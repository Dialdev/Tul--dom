<?
$MESS ['CATALOG_COMPARE_ELEMENTS'] = "Список сравниваемых товаров";
?>