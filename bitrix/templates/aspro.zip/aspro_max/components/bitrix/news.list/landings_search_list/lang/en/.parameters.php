<?
$MESS['TITLE_BLOCK_NAME'] = "Заголовок блока";
$MESS['BLOCK_NAME'] = "Похожие запросы";
?>