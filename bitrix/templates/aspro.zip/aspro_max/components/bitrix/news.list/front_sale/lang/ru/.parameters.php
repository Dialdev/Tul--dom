<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Выводить дату элемента";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Выводить название элемента";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Выводить изображение для анонса";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Выводить текст анонса";

$MESS ['TITLE_BLOCK_NAME'] = "Заголовок блока";
$MESS ['TITLE_BLOCK_ALL_NAME'] = "Заголовок на все новости";
$MESS ['BLOCK_NAME'] = "Новости";
$MESS ['BLOCK_ALL_NAME'] = "Все новости";
$MESS ['ALL_URL_NAME'] = "Ссылка на все новости";
$MESS ['DISPLAY_DATE'] = "Отображать дату";
$MESS ['KEY_MAP_NAME'] = "Ключ карты";
$MESS ['IMG_POSITION_NAME'] = "Положение картинки";
$MESS ['RIGHT_POS'] = "справа";
$MESS ['LEFT_POS'] = "слева";
$MESS ['NO_MARGIN_NAME'] = "Использовать отступ между блоками";
$MESS ['FILLED_NAME'] = "Заливать блоки";
$MESS ['BG_POSITION_NAME'] = "Расположение фоновой картинки";
$MESS ['TOP_LEFT'] = "сверху слева";
$MESS ['TOP_CENTER'] = "сверху по центру";
$MESS ['TOP_RIGHT'] = "сверху справа";
$MESS ['CENTER_LEFT'] = "по центру слева";
$MESS ['CENTER_CENTER'] = "по центру по центру";
$MESS ['CENTER_RIGHT'] = "по центру справа";
$MESS ['BOTTOM_LEFT'] = "снизу слева";
$MESS ['BOTTOM_CENTER'] = "снизу по центру";
$MESS ['BOTTOM_RIGHT'] = "снизу справа";
?>