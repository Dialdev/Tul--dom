<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Выводить дату элемента";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Выводить название элемента";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Выводить изображение для анонса";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Выводить текст анонса";

$MESS ['TITLE_BLOCK_NAME'] = "Заголовок блока";
$MESS ['TITLE_BLOCK_ALL_NAME'] = "Заголовок на все новости";
$MESS ['BLOCK_NAME'] = "Новости";
$MESS ['BLOCK_ALL_NAME'] = "Все новости";
$MESS ['ALL_URL_NAME'] = "Ссылка на все новости";
$MESS ['DISPLAY_DATE'] = "Отображать дату";
$MESS ['KEY_MAP_NAME'] = "Ключ карты";
$MESS ['SHOW_ADD_REVIEW_NAME'] = "Разрешить добавлять отзыв";
$MESS ['TITLE_ADD_REVIEW_NAME'] = "Оставить отзыв";
$MESS ['INCLUDE_FILE_NAME'] = "Файл с дополнительным текстом";
$MESS ['COMPACT_NAME'] = "Компактный";
$MESS ['SIZE_IN_ROW_NAME'] = "Элементов в строке";
?>