<?
$MESS['T_IBLOCK_DESC_NEWS_DATE'] = "Выводить дату элемента";
$MESS['T_IBLOCK_DESC_NEWS_NAME'] = "Выводить название элемента";
$MESS['T_IBLOCK_DESC_NEWS_PICTURE'] = "Выводить изображение для анонса";
$MESS['T_IBLOCK_DESC_NEWS_TEXT'] = "Выводить текст анонса";

$MESS['TITLE_BLOCK_NAME'] = "Заголовок блока";
$MESS['TITLE_BLOCK_ALL_NAME'] = "Заголовок на все новости";
$MESS['BLOCK_NAME'] = "Новости";
$MESS['BLOCK_ALL_NAME'] = "Все новости";
$MESS['ALL_URL_NAME'] = "Ссылка на все новости";
$MESS['DISPLAY_DATE'] = "Отображать дату";
$MESS['KEY_MAP_NAME'] = "Ключ карты";
$MESS['SHOW_SUBSCRIBE_NAME'] = "Отображать подписку";
$MESS['TITLE_SUBSCRIBE_NAME'] = "Текст подписки";
$MESS['INCLUDE_FILE_NAME'] = "Файл с дополнительным текстом";
$MESS['TYPE_IMG_NAME'] = "Тип картинки";
$MESS['BG_IMG'] = "фоновая картинка";
$MESS['SM_IMG'] = "маленькая картинка";
$MESS['MD_IMG'] = "средняя картинка";
$MESS['BIG_IMG'] = "большая картинка";
$MESS['NO_MARGIN_NAME'] = "Использовать отступ между блоками";
$MESS['FILLED_NAME'] = "Заливать блоки";
$MESS['TRANSPARENT_NAME'] = "Прозрачные блоки";
$MESS['BORDERED_NAME'] = "Отображать рамку";
$MESS['SHOW_SECTION_NAME'] = "Отображать название раздела";
$MESS['BG_POSITION_NAME'] = "Расположение фоновой картинки";
$MESS['TOP_LEFT'] = "сверху слева";
$MESS['TOP_CENTER'] = "сверху по центру";
$MESS['TOP_RIGHT'] = "сверху справа";
$MESS['CENTER_LEFT'] = "по центру слева";
$MESS['CENTER_CENTER'] = "по центру по центру";
$MESS['CENTER_RIGHT'] = "по центру справа";
$MESS['BOTTOM_LEFT'] = "снизу слева";
$MESS['BOTTOM_CENTER'] = "снизу по центру";
$MESS['BOTTOM_RIGHT'] = "снизу справа";
$MESS['FON_BLOCK_2_COLS_NAME'] = "Широкий блок с фоном";
$MESS['TITLE_SHOW_FON_NAME'] = "Отображать текст на фоне картинки";
$MESS['HALF_BLOCK_NAME'] = "Отображать в 2 блока";
$MESS ['SIZE_IN_ROW_NAME'] = "Элементов в строке";

$MESS ['USE_BG_IMAGE_ALTERNATE_NAME'] = "Включить чередование больших блоков";
$MESS ['ALL_BLOCK_BG_NAME'] = "Блок с фоном";
?>