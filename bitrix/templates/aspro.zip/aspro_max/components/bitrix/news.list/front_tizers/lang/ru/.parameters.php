<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Выводить дату элемента";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Выводить название элемента";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Выводить изображение для анонса";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Выводить текст анонса";

$MESS ['INCLUDE_FILE_NAME'] = "Файл с дополнительным текстом";
$MESS ['SIZE_IN_ROW_NAME'] = "Элементов в строке";
$MESS ['CENTERED_NAME'] = "Центрировать";
$MESS ['IMG_POSITION_NAME'] = "Расположение иконки";
$MESS ['TOP'] = "сверху";
$MESS ['LEFT'] = "слева";
$MESS ['RIGHT'] = "справа";
?>