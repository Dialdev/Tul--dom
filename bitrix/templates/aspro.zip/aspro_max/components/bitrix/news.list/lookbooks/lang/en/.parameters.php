<?
$MESS ['TITLE_BLOCK_NAME'] = "Заголовок блока";
$MESS ['TITLE_BLOCK_ALL_NAME'] = "Заголовок на все новости";
$MESS ['BLOCK_NAME'] = "Новости";
$MESS ['BLOCK_ALL_NAME'] = "Все новости";
$MESS ['ALL_URL_NAME'] = "Ссылка на все новости";

$MESS ['BG_POSITION_NAME'] = "Расположение фоновой картинки";
$MESS ['TOP_LEFT'] = "сверху слева";
$MESS ['TOP_CENTER'] = "сверху по центру";
$MESS ['TOP_RIGHT'] = "сверху справа";
$MESS ['CENTER_LEFT'] = "по центру слева";
$MESS ['CENTER_CENTER'] = "по центру по центру";
$MESS ['CENTER_RIGHT'] = "по центру справа";
$MESS ['BOTTOM_LEFT'] = "снизу слева";
$MESS ['BOTTOM_CENTER'] = "снизу по центру";
$MESS ['BOTTOM_RIGHT'] = "снизу справа";
$MESS ['SIZE_IN_ROW_NAME'] = "Элементов в строке";

$MESS["T_SECTION_CODE"] = "Символьный код раздела";
$MESS["T_TYPE_BLOCK"] = "Тип блока";
$MESS["T_USE_TYPE_BLOCK"] = "Использовать тип блоков";
$MESS["T_SHOW_LONG_FIRST_ROW"] = "Отображать высокую первую строку с элементами";
?>