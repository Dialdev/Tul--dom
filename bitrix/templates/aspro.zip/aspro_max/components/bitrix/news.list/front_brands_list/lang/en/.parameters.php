<?
$MESS ['T_IBLOCK_DESC_NEWS_DATE'] = "Выводить дату элемента";
$MESS ['T_IBLOCK_DESC_NEWS_NAME'] = "Выводить название элемента";
$MESS ['T_IBLOCK_DESC_NEWS_PICTURE'] = "Выводить изображение для анонса";
$MESS ['T_IBLOCK_DESC_NEWS_TEXT'] = "Выводить текст анонса";

$MESS ['TITLE_BLOCK_NAME'] = "Заголовок блока";
$MESS ['TITLE_BLOCK_ALL_NAME'] = "Заголовок на все новости";
$MESS ['BLOCK_NAME'] = "Новости";
$MESS ['BLOCK_ALL_NAME'] = "Все новости";
$MESS ['ALL_URL_NAME'] = "Ссылка на все новости";
$MESS ['DISPLAY_DATE'] = "Отображать дату";
$MESS ['INCLUDE_FILE_NAME'] = "Страница с дополнительным текстом";
?>