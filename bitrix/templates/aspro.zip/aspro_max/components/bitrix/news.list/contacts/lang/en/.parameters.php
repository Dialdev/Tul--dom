<?
$MESS['SHOW_DETAIL_LINK'] = 'Отображать ссылку на детальную страницу';
$MESS['COUNT_IN_LINE'] = 'Количество элементов в строке';
$MESS['VIEW_TYPE'] = 'Вид отображения';
$MESS['VIEW_TYPE_LIST'] = 'Список';
$MESS['VIEW_TYPE_TABLE'] = 'Плитка';
$MESS['VIEW_TYPE_ACCORDION'] = 'Аккордион';
$MESS['SHOW_TABS'] = 'Показывать табы';
$MESS['SHOW_SECTION_PREVIEW_DESCRIPTION'] = 'Выводить краткое описание раздела';
$MESS['IMAGE_POSITION'] = 'Положение картинки анонса';
$MESS['IMAGE_POSITION_LEFT'] = 'Слева';
$MESS['IMAGE_POSITION_RIGHT'] = 'Справа';
$MESS['IMAGE_POSITION_TOP'] = 'Сверху';
$MESS['IMAGE_POSITION_BOTTOM'] = 'Снизу';
$MESS['USE_SHARE'] = 'Показывать ссылки на соцсети';
?>