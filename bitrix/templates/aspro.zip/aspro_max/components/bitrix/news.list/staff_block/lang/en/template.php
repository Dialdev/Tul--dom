<?
$MESS["CT_BNL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["TITLE_STAFF"] = "Наша команда";
$MESS['S_TO_SHOW_ALL_STAFF'] = 'Все сотрудники';
$MESS['MORE'] = 'Подробнее';
$MESS['SEND_MESSAGE_BUTTON_TEXT'] = 'Написать сообщение';
?>