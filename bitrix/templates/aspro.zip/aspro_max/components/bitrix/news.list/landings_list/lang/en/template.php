<?
$MESS["CT_BNL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["SHOW_ALL"] = "Показать все";
$MESS["HIDE"] = "Свернуть";
$MESS["RESET_LANDING"] = "Сбросить";
?>