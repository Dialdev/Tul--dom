<?
$MESS["CT_BNL_ELEMENT_DELETE_CONFIRM"] = "Будет удалена вся информация, связанная с этой записью. Продолжить?";
$MESS["NEWS_TITLE"] = "Новости";
$MESS["ALL_NEWS"] = "Все новости";
?>