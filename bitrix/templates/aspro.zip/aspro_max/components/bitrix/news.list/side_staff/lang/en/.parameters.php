<?
$MESS ['TITLE_BLOCK_NAME'] = "Заголовок блока";
$MESS ['BLOCK_NAME'] = "Новости";
$MESS ['ALL_URL_NAME'] = "Ссылка на все новости";
$MESS ['TITLE_BLOCK_ALL_NAME'] = "Заголовок на все новости";
$MESS ['BLOCK_ALL_NAME'] = "Все новости";
$MESS ['SHOW_DATE_NAME'] = "Показывать дату";
?>