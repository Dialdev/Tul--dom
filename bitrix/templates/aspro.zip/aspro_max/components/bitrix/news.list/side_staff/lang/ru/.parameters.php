<?
$MESS ['T_TITLE_BLOCK'] = "Заголовок блока";
?>