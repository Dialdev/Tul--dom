<?
	$MESS["SOCSERV_AS_USER_FORM"]="Быстрый вход через соцсети";
?>